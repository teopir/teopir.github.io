The code has been tested using python 2.7.14 and 3.6.1 provided by anaconda (on linux)

Python 2.7
==========
conda create -n py27 python=2.7 anaconda
conda activate py27
conda install -c conda-forge tqdm

python mainTP3_PG.py

Python 3.6
==========
conda create -n py36 python=3.6 anaconda
conda activate py36
conda install -c conda-forge tqdm

python mainTP3_PGs.py
