You can download the dataset at
http://files.grouplens.org/datasets/movielens/ml-1m.zip
