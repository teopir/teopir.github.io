The code has been tested using python 3.6.1 provided by anaconda (on linux)

Environment in anaconda
=======================
conda create -n py36 python=3.6 anaconda
conda activate py36
conda install tk


python main_tp1_ex2.py
