clc;
clear all;
close all;

random_state = randi([0, 24532523]);

noise = 0.1;
model = ToyLinearMABModel(8, 20, random_state, noise);

% model = ColdStartMovieLensModel(random_state, noise);

n_a = model.n_actions();
d = model.n_features();

T = 6000;
nb_simu = 50; % you may want to change this!

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define the algorithms
% - Random
% - Linear UCB
% - Eps Greedy
% and test it!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fprintf('Simulating %s...', alg_name);

regret = zeros(nb_simu, T);
norm_dist = zeros(nb_simu, T);

h = waitbar(0,'Initializing waitbar...');
for k = 1:nb_simu
    waitbar(k/nb_simu,h,sprintf('%d/%d', k, nb_simu));
    
    for t = 1:T
        a_t = ...  % algorithm picks the action
        r_t = model.reward(a_t); % get the reward
        
        % do something (update algorithm)

        % store regret
        regret(k, t) = model.best_arm_reward() - r_t;
        norm_dist(k, t) = norm(theta_hat - model.real_theta, 2);
    end
end
delete(h);

% compute average (over sim) of the algorithm performance and plot it
mean_norms = ...
mean_regret = ...

figure(1);
subplot(121);
plot(mean_norms, 'LineWidth', 2);
ylabel('$\|\hat{\theta} - \theta\|_{2}$','Interpreter','latex');
xlabel('Rounds');
legend({alg_name});

subplot(122);
plot(cumsum(mean_regret), 'LineWidth', 2);
ylabel('Cumulative Regret');
xlabel('Rounds');
legend({alg_name});