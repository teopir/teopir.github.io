The code has been tested using python 2.7.14 and 3.6.1 provided by anaconda (on linux)

Attention: for python 2.7 you need future

Python 3.6
==========
conda create -n py27 python=2.7 anaconda
conda activate py27
conda install tk future

python main_tp1_ex2.py

Python 3.6
==========
conda create -n py36 python=3.6 anaconda
conda activate py36
conda install tk

python main_tp1_ex2.py
