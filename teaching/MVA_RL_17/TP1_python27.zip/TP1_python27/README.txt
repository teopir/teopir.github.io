The code has been tested using python 2.7.14 provided by anaconda (on linux)

Environment in anaconda
=======================
conda create -n py27 python=2.7 anaconda
conda activate py27
conda install tk


python main_tp1_ex2.py
