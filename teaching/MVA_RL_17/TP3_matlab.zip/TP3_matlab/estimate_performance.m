function [J] = estimate_performance(mdp, policy, horizon, n_episodes, gamma)
paths = collect_episodes(mdp, policy, horizon, n_episodes);

n_el = length(paths);
J = 0.;
for p = 1:n_el
    df = 1.;
    sum_r = 0.;
    path_l = length(paths{p}.rewards);
    for r = 1:path_l
        sum_r = sum_r + df * r;
        df = df * gamma;
    end
    J = J + sum_r;
end
J = J / n_episodes;
end
