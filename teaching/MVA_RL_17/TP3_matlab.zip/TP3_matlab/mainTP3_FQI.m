close all;
clear all;
clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define the environment and the parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

env = LQG1D('random');
discount = 0.9;
horizon = 50;

discrete_actions = linspace(-8, 8, 20);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Show the optimal Q-function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

discrete_states = linspace(-10, 10, 20);

[S, A] = meshgrid(discrete_states, discrete_actions);
S = S(:);
A = A(:);

K = env.computeOptimalK(discount);
cov = 0.001;
fprintf('Optimal K: %f Covariance S: %f\n', K, cov);

Q_opt = zeros(size(S,1), 1);
for i=1:size(S,1)
    s = S(i);
    a = A(i);
    Q_opt(i) = env.computeQFunction(s, a, K, cov, discount, 1);
end

figure();
scatter3(S, A, Q_opt);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Collect the samples using the behavioural policy
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% You should use discrete actions
beh_policy = [];
n_episodes = 100;

dataset = collect_episodes(env, beh_policy, horizon, n_episodes);

% define FQI
% to evaluate the policy you can use estimate_performance

% % plot obtained Q-function against the true one
J = estimate_performance(env, fqi, horizon, n_episodes, discount);
printf('Policy performance: %f \n', J);

