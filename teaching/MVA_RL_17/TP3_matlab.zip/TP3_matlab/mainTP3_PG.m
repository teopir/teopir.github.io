close all;
clear all;
clc;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define the environment and the policy
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
env = LQG1D('random');

policy = 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiments parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% We will collect N trajectories per iteration
N = 100;
% Each trajectory will have at most T time steps
T = 100;
% Number of policy parameters updates
n_itr =1;
% Set the discount factor for the problem
discount = 0.9;
% Learning rate for the gradient update
learning_rate = 0.1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% define the update rule (stepper)
stepper =   % e.g., ConstantStep(learning_rate), adam or anything you want

% fill the following part of the code with
%  - REINFORCE estimate i.e. gradient estimate
%  - update of policy parameters using the steppers
%  - average performance per iteration
%  - distance between optimal mean parameter and the one at it k
mean_parameters = [];
avg_return = [];
for it=1:n_itr

    paths = collect_episodes(env, policy, T, N);

    % do something

end

% plot the average return obtained by simulating the policy
% at each iteration of the algorithm (this is a rought estimate
% of the performance
figure()
plot(avg_return)

% plot the distance between the optimal parametrization and the one
% of iteration k (parameters of the mean)
figure()
plot(mean_parameters)
