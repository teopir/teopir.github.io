function [paths] = collect_episodes(env, policy, horizon, n_episodes)

    for n=1:n_episodes
        states = [];
        actions = [];
        rewards = [];
        next_states = [];
        
        state = env.reset();
        for t=1:horizon
            action = policy.draw_action(state);
            [next_state, reward, terminal] = env.step(action);
            states = [states; state];
            actions = [actions; action];
            rewards = [rewards; reward];
            next_states = [next_states; next_state];
            state = next_state;
            if terminal
                % Finish rollout if terminal state reached
                break
                % We need to compute the empirical return for each time step along the
                % trajectory
            end
        end
        
        paths{n} = struct('states', states, ...
            'actions', actions, ...
            'rewards', rewards, ...
            'next_states', next_states ...
            );
        
    end
end
