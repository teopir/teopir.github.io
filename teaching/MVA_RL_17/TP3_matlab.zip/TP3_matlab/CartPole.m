classdef CartPole<handle
    properties
        gravity
        masscart
        masspole
        total_mass
        length
        polemass_length
        force_mag
        tau
        theta_threshold_radians
        x_threshold
        action_space
        state
        steps_beyond_done
    end
    methods
        function self = CartPole()
            self.gravity = 9.8;
            self.masscart = 1.0;
            self.masspole = 0.1;
            self.total_mass = (self.masspole + self.masscart);
            self.length = 0.5; % actually half the pole's length
            self.polemass_length = (self.masspole * self.length);
            self.force_mag = 10.0;
            self.tau = 0.02;  % seconds between state updates
            
            % Angle at which to fail the episode
            self.theta_threshold_radians = 12 * 2 * pi / 360;
            self.x_threshold = 2.4;
            self.action_space = [0,1];
            self.steps_beyond_done =-1;
            
        end
        
        function [state] = reset(self)
            xmin=-0.05; xmax=0.05;
            self.state = rand(4,1) * (xmax-xmin) + xmin;
            self.steps_beyond_done = -1;
            state = self.state;
        end
        
        function [next_state, reward, done] = step(self, action)
            x = self.state(1);
            x_dot = self.state(2);
            theta = self.state(3);
            theta_dot = self.state(4);
            force = -self.force_mag;
            if action == 1
                force = self.force_mag;
            end
            costheta = cos(theta);
            sintheta = sin(theta);
            temp = (force + self.polemass_length * theta_dot * theta_dot * sintheta) / self.total_mass;
            thetaacc = (self.gravity * sintheta - costheta* temp) / (self.length * (4.0/3.0 - self.masspole * costheta * costheta / self.total_mass));
            xacc  = temp - self.polemass_length * thetaacc * costheta / self.total_mass;
            x  = x + self.tau * x_dot;
            x_dot = x_dot + self.tau * xacc;
            theta = theta + self.tau * theta_dot;
            theta_dot = theta_dot + self.tau * thetaacc;
            self.state = [x,x_dot,theta,theta_dot];
            done =  x < -self.x_threshold ...
                | x > self.x_threshold ...
                | theta < -self.theta_threshold_radians ...
                | theta > self.theta_threshold_radians;
            
            if ~done
                reward = 1.0;
            elseif self.steps_beyond_done == -1
                % Pole just fell!
                self.steps_beyond_done = 0;
                reward = 1.0;
            else
                self.steps_beyond_done = self.steps_beyond_done + 1;
                reward = 0.0;
            end
            next_state = self.state;
        end
    end
end

