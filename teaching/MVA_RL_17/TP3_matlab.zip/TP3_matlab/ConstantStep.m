classdef ConstantStep<handle
    properties
        learning_rate
    end
    methods
        function self = ConstantStep(lr)
            self.learning_rate = lr;
        end
        
        function dt = update(self, gt)
            dt = self.learning_rate * gt;
        end
    end
end