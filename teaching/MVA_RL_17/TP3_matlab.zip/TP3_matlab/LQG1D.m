classdef LQG1D<handle
    properties
        max_pos
        max_action
        sigma_noise
        A
        B
        Q
        R
        initial_states
        state
        initial_states_type
    end
    methods
        function self = LQG1D(initial_states_type)
            self.max_pos = 500;
            self.max_action = 500;
            self.sigma_noise = -1;
            self.A = [1];
            self.B = [1];
            self.Q = [0.5];
            self.R = [0.5];
            
            self.initial_states = [-10, -5, 5, 10];
            self.initial_states_type = initial_states_type;
            
        end
        
        function [state] = reset(self)
            if self.initial_states_type == 'random'
                xmin = -10;
                xmax = 10;
                self.state = rand()*(xmax-xmin) +xmin;
            else
                error('not implemented');
            end
            state = self.state;
        end
        
        function [next_state, reward, terminal] = step(self, action)
            u = min(self.max_action, max(-self.max_action, action));
            noise = 0;
            
            if self.sigma_noise > 0
                noise = randn() * self.sigma_noise;
            end
            xn = self.A * self.state + self.B * u + noise;
            
            xn = min(self.max_pos, max(-self.max_pos, xn));
            cost = self.state' * self.Q * self.state + u'*self.R*u;
            
            self.state = xn;
            next_state = xn;
            reward = -cost;
            terminal = 0;
        end
        
        function [P] = computeP2(self, K, gamma)
            I = eye(size(self.Q, 1), size(self.Q, 2));
            if self.A == I && self.B == I
                P = (self.Q + K'*self.R*K) / (I - gamma * (I + 2 * K + K.^2));
            else
                tolerance = 0.0001;
                converged = false;
                P = eye(size(self.Q, 1), size(self.Q, 2));
                while ~converged
                    Pnew = self.Q + gamma * self.A' * P * self.A + gamma * K' *self.B'*P*self.A+ ...
                        gamma *self.A' * P * self.B * K + K' * self.B' * P * self.B *K + ...
                        K' * self.R * K
                    
                    converged = max(abs(P - Pnew)) < tolerance;
                    P = Pnew;
                end
            end
        end
        
        function [K] = computeOptimalK(self, gamma)
            P = eye(size(self.Q, 1), size(self.Q, 2));
            for i=1:100
                K = -gamma * inv(self.R + gamma * self.B' * P * self.B) * self.B' * P * self.A;
                P = self.computeP2(K, gamma);
            end
            K = -gamma * inv(self.R + gamma * self.B' * P * self.B) * self.B' * P * self.A;
        end
        
        
        function [Qfun] = computeQFunction(self, x, u, K, Sigma, gamma, n_random_xn)
            P = self.computeP2(K, gamma);
            Qfun = 0;
            for i= 1:n_random_xn
                noise = 0;
                if self.sigma_noise > 0
                    noise = randn() * self.sigma_noise;
                end
                action_noise = mvnrnd(zeros(size(Sigma,1), 1), Sigma, 1);
                nextstate = self.A * x + self.B*u + action_noise + noise;
                Qfun = Qfun - x' * self.Q * x - ...
                    u' * self.R * u - ...
                    gamma * nextstate' * P * nextstate - ...
                    (gamma / (1-gamma)) * trace(Sigma*(self.R + gamma *self.B'*P*self.B));
            end
            Qfun = Qfun / n_random_xn;
        end
    end
end
