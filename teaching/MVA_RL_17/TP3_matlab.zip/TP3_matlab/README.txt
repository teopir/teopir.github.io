The code has been tested using Matlab R2016b (on linux)
